window.KAWA_FORM_DATA = {
  "sections": [
    {
      "id": "farmer",
      "title": "Farmer Interview",
      "questions": [
        {
          "type": "section",
          "label": "Farmer full name"
        },
        {
          "type": "section",
          "label": "Farmer gender"
        },
        {
          "type": "section",
          "label": "State & municipality"
        },
        {
          "type": "section",
          "label": "GPS coordinates (farm HQ)"
        },
        {
          "type": "section",
          "label": "Total farm area (ha)"
        },
        {
          "type": "section",
          "label": "Cocoa area (ha)"
        },
        {
          "type": "section",
          "label": "Household size (adults / children)"
        },
        {
          "type": "section",
          "label": "Date of visit"
        },
        {
          "type": "section",
          "label": "Field officer name"
        },
        {
          "type": "section",
          "label": "Cooperative / association"
        },
        {
          "type": "section",
          "label": "Certification held"
        },
        {
          "type": "field",
          "label": "Q#",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 1 — LAND TENURE & CAR"
        },
        {
          "type": "field",
          "label": "Q1",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q2",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q3",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q4",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q6",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q7",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q8",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q9",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q10",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q11",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q12",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q13",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q14",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 2 — DEFORESTATION & ENVIRONMENTAL COMPLIANCE"
        },
        {
          "type": "field",
          "label": "Q15",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q16",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q17",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q18",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q19",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q20",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q21",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q22",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q23",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q24",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q25",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q26",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 3 — LABOUR PRACTICES & CHILD LABOUR"
        },
        {
          "type": "field",
          "label": "Q27",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q28",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q30",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q31",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q32",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q33",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q34",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q35",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q36",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q37",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q38",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q39",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q41",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q42",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 4 — AGROCHEMICAL & INPUT MANAGEMENT"
        },
        {
          "type": "field",
          "label": "Q43",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q44",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q45",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q46",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q47",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q48",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q49",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q50",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q51",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 5 — FINANCE, LOANS & BORROWING UNDERSTANDING"
        },
        {
          "type": "field",
          "label": "Q52",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q53",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q54",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q55",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q56",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q57",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q58",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q59",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q60",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q61",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q62",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q63",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q64",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 6 — COMMUNITY GUARANTEE & COLLATERAL"
        },
        {
          "type": "field",
          "label": "Q65",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q66",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q67",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q68",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q69",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q70",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q71",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q72",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q73",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q74",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q75",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q76",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q77",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 7 — GENDER & SOCIAL INCLUSION"
        },
        {
          "type": "field",
          "label": "Q78",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q79",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q80",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q81",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q82",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q83",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q84",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q85",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 8 — CLIMATE RISK & ENVIRONMENTAL STEWARDSHIP"
        },
        {
          "type": "field",
          "label": "Q86",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q87",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q88",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q89",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q90",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q91",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q92",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q93",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q94",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Q95",
          "input": "text"
        }
      ]
    },
    {
      "id": "observation",
      "title": "Farm Observation Checklist",
      "questions": [
        {
          "type": "field",
          "label": "Farm / farmer ID",
          "input": "text"
        },
        {
          "type": "field",
          "label": "GPS coordinates (farm HQ)",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Date of visit",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Field officer",
          "input": "text"
        },
        {
          "type": "section",
          "label": "Section 1: LAND & ENVIRONMENTAL"
        },
        {
          "type": "status_notes",
          "label": "1. Farm boundaries physically walked and GPS polygon captured — Ask Violet to provide GPS locations and trace these along farm boundaries with phone maps. Hopefully, the Violet team can do this with you monitoring"
        },
        {
          "type": "status_notes",
          "label": "2. CAR number verified on-site against car.gov.br printout — Violet to provide in advance/ check against car.gov.br"
        },
        {
          "type": "status_notes",
          "label": "3. CAR polygon overlaid on satellite image — no inconsistency with actual farm boundary — Same as farm boundaries. Violet can provide and walk you through"
        },
        {
          "type": "status_notes",
          "label": "4. Reserva Legal area identified and physically inspected — vegetation status noted — To ask farmers to show you the legal reserve area to ensure preservation, no encroachment etc."
        },
        {
          "type": "status_notes",
          "label": "5. APP / riparian buffer strips present and vegetated along all watercourses — Same as above"
        },
        {
          "type": "status_notes",
          "label": "6. No evidence of recent deforestation (fresh stumps, burn scars, bare soil clearing) — General inspection across farm, in particular around boundaries, legal reserve, and APP zones"
        },
        {
          "type": "status_notes",
          "label": "7. No active deforestation observed during visit — Same as above"
        },
        {
          "type": "status_notes",
          "label": "8. No IBAMA embargo or environmental infraction notice visible on farm — Lookout for any signs or notices"
        },
        {
          "type": "status_notes",
          "label": "9. Farm not within or adjacent to a Conservation Unit (verified GIS overlay) — Check with Violet if available map data for conservation areas and indigenous lands"
        },
        {
          "type": "status_notes",
          "label": "10. Farm not overlapping with Indigenous Land or Quilombola territory (verified GIS)"
        },
        {
          "type": "status_notes",
          "label": "11. Presence of native shade trees in cocoa plots (agroforestry / cabruca system) — Check tree species"
        },
        {
          "type": "status_notes",
          "label": "12. Soil erosion or degradation — note severity and location if present — Check for exposed tree roots, small channels, soil build-up around fences"
        },
        {
          "type": "status_notes",
          "label": "13. Water bodies (rivers, streams, ponds) condition — sedimentation, colour, odour assessed — Check for clarity, eutrophication (algal bloom at surface)"
        },
        {
          "type": "status_notes",
          "label": "14. Evidence of burning (charcoal, ash, scorched vegetation) on property — note if found — Check for charcoal, ash, scorched vegetation"
        },
        {
          "type": "section",
          "label": "Section 2: LABOUR & CHILD LABOUR"
        },
        {
          "type": "status_notes",
          "label": "15. Children observed on farm — ages estimated and activity noted — Ask for ages of chlidren on farm. Note if any serious suspicions of age significantly lower than stated."
        },
        {
          "type": "status_notes",
          "label": "16. NO children observed in cocoa harvest, handling chemicals, or using bladed tools"
        },
        {
          "type": "status_notes",
          "label": "17. All workers on site appear to be adults (18+)"
        },
        {
          "type": "status_notes",
          "label": "18. Workers observed using PPE during pesticide application or handling"
        },
        {
          "type": "status_notes",
          "label": "19. Worker welfare: toilet facilities, clean drinking water, shaded rest area visible"
        },
        {
          "type": "status_notes",
          "label": "20. No workers observed in apparent distress, under coercion, or physically restrained"
        },
        {
          "type": "section",
          "label": "Section 3: CHEMICAL STORAGE & HANDLING"
        },
        {
          "type": "status_notes",
          "label": "23. Agrochemical store located and position relative to water sources and dwellings noted — How close are chemicals stored compared to water sources and housing/ worker accomodation?"
        },
        {
          "type": "status_notes",
          "label": "24. Store is locked, ventilated, and built of non-absorbent materials"
        },
        {
          "type": "status_notes",
          "label": "25. All products in original labelled containers — no unlabelled or decanted products"
        },
        {
          "type": "status_notes",
          "label": "26. No MAPA-prohibited products present (record any prohibited products found by name) — Note all product names to be checked later."
        },
        {
          "type": "status_notes",
          "label": "27. No WHO Class Ia or Ib products observed (record any found by name and active ingredient)"
        },
        {
          "type": "status_notes",
          "label": "29. Full PPE kit present — gloves, boots, overalls, mask, goggles — condition assessed"
        },
        {
          "type": "status_notes",
          "label": "30. Empty containers: triple-rinsed, punctured, stored for inpEV / campo limpo collection"
        },
        {
          "type": "status_notes",
          "label": "31. No empty containers burned, buried, or left in fields or near water sources"
        },
        {
          "type": "status_notes",
          "label": "32. Spray equipment in good condition — no visible leaks or damage"
        },
        {
          "type": "section",
          "label": "Section 4: FARM MANAGEMENT & PRODUCTION"
        },
        {
          "type": "status_notes",
          "label": "34. Cocoa tree condition assessed — estimated age, variety, disease pressure (witches' broom, black pod)"
        },
        {
          "type": "status_notes",
          "label": "35. Shade canopy cover estimated (%) — adequate density for climate resilience"
        },
        {
          "type": "status_notes",
          "label": "37. Harvest infrastructure: fermentation boxes, drying facilities — hygiene and condition assessed"
        },
        {
          "type": "status_notes",
          "label": "38. Cocoa storage — moisture protection, pest/rodent control, stored separately from chemicals"
        },
        {
          "type": "status_notes",
          "label": "39. Traceability: weighing records, delivery receipts, cooperative sale documentation present"
        },
        {
          "type": "status_notes",
          "label": "40. Farm records / farmer notebook maintained (inputs, yields, sales)"
        },
        {
          "type": "status_notes",
          "label": "41. Certification signage or documentation (RA, Fairtrade, organic) present if claimed"
        },
        {
          "type": "section",
          "label": "Section 6: DOCUMENTS TO PHOTOGRAPH / SCAN"
        },
        {
          "type": "status_notes",
          "label": "42. CAR registration certificate or SICAR printout"
        },
        {
          "type": "status_notes",
          "label": "43. Land title / escritura / CCIR / INCRA título (whichever applies to this farm)"
        },
        {
          "type": "status_notes",
          "label": "44. Loan contract — cover page, key terms page, and signature page"
        },
        {
          "type": "status_notes",
          "label": "45. Agronomic prescriptions (receitas agronômicas) for all pesticides in use"
        },
        {
          "type": "status_notes",
          "label": "46. Cooperative membership certificate"
        },
        {
          "type": "status_notes",
          "label": "47. Certification audit report / certificate (Rainforest Alliance, Fairtrade, organic) if held"
        },
        {
          "type": "status_notes",
          "label": "48. Environmental infraction notices or IBAMA embargoes (if any exist)"
        },
        {
          "type": "status_notes",
          "label": "49. Worker employment contracts / fichas de registro (if hired labour is used)"
        },
        {
          "type": "status_notes",
          "label": "50. GPS polygon map of farm (field-captured or CAR polygon printout)"
        },
        {
          "type": "status_notes",
          "label": "51. Photograph of farm entrance with GPS geotag"
        },
        {
          "type": "status_notes",
          "label": "52. Photograph of Reserva Legal area vegetation"
        },
        {
          "type": "status_notes",
          "label": "53. Photograph of agrochemical storage area"
        },
        {
          "type": "status_notes",
          "label": "54. Photograph of cocoa stand showing variety and condition"
        },
        {
          "type": "status_notes",
          "label": "55. Photograph of fermentation boxes and / or drying facilities"
        }
      ]
    },
    {
      "id": "agent",
      "title": "Field Extension Agents",
      "questions": [
        {
          "type": "field",
          "label": "Staff name",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Organisation / role",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Date of interview",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Location / office",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Interviewer name",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Interview method (In person / Remote / Phone)",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 1 — BACKGROUND & CASELOAD"
        },
        {
          "type": "rating_notes",
          "label": "Q1. How long have you been working as a field extension agent for Kawa? What was your role before this? — Assess experience level and continuity."
        },
        {
          "type": "rating_notes",
          "label": "Q2. How many farmers are currently in your caseload? How many farm visits do you typically complete per month? — Benchmark: minimum 2 visits/farmer/season. Flag if >150 farmers per agent."
        },
        {
          "type": "rating_notes",
          "label": "Q3. What formal training or qualifications do you have in agronomy, agriculture, or a related field? — Ask to see certificates or training records. Note any gaps in ESG-related training."
        },
        {
          "type": "rating_notes",
          "label": "Q4. What ESG or sustainability training have you received from Kawa or an external provider? When was the most recent training? — Look for training on: child labour, deforestation, chemical safety, gender, grievances."
        },
        {
          "type": "rating_notes",
          "label": "Q5. Do you have a written job description that includes ESG responsibilities? Are ESG KPIs included in your performance review? — Absence of ESG KPIs is a governance gap. Ask to see the job description."
        },
        {
          "type": "section",
          "label": "SECTION 2 — CHILD LABOUR & SAFEGUARDING"
        },
        {
          "type": "rating_notes",
          "label": "Q6. Can you describe what 'child labour' and 'worst forms of child labour' mean under Brazilian law (ECA) and ILO Convention 182? — Test knowledge: minimum age 14; hazardous work prohibited under 18. Flag inability to define."
        },
        {
          "type": "rating_notes",
          "label": "Q7. Have you ever observed or suspected child labour on a farm in your caseload? What did you do? — Listen for: immediate reporting, documentation, follow-up visit, referral to social services."
        },
        {
          "type": "rating_notes",
          "label": "Q8. Does Kawa have a written child labour policy and a clear escalation procedure? Have you read it? Can you describe the steps? — Ask for the policy document reference. Inability to describe steps = procedural gap."
        },
        {
          "type": "rating_notes",
          "label": "Q9. How do you verify that school-age children in farmer households are attending school regularly? — Best practice: confirm school enrolment record or directly with school. Note any proxy methods."
        },
        {
          "type": "rating_notes",
          "label": "Q10. Do you ask farmers directly about children working on the farm during your visits? What questions do you ask? — Assess whether questioning is routine and specific, or superficial."
        },
        {
          "type": "rating_notes",
          "label": "Q11. Are you aware of community or government resources (CRAS, Conselho Tutelar) available to refer child labour cases? — Knowledge of local referral pathways is essential for effective safeguarding."
        },
        {
          "type": "section",
          "label": "SECTION 3 — DEFORESTATION & ENVIRONMENTAL MONITORING"
        },
        {
          "type": "rating_notes",
          "label": "Q12. How do you monitor for deforestation or land clearing among your farmers? What tools or systems does Kawa provide? — Best practice: satellite monitoring (PRODES/DETER alerts), farm polygon mapping, field observation."
        },
        {
          "type": "rating_notes",
          "label": "Q13. Do you verify each farmer's CAR registration during your visits? How do you check the status and accuracy of the CAR? — Should be checking car.gov.br or SICAR. Note whether this is routine or ad hoc."
        },
        {
          "type": "rating_notes",
          "label": "Q14. Do you check whether any farmers' farms overlap with Conservation Units, Indigenous Lands, or IBAMA embargoes? — Best practice: GIS overlay check using FUNAI/ICMBio/IBAMA datasets."
        },
        {
          "type": "rating_notes",
          "label": "Q15. Have any farmers in your caseload received an IBAMA infraction notice or been under embargo for deforestation? What happened? — Listen for: exclusion from programme, remediation plan, continued support with conditions."
        },
        {
          "type": "rating_notes",
          "label": "Q16. Does Kawa have a deforestation cut-off date (e.g. post-2020 = exclusion)? Are you clear on what to do if a polygon shows post-cut-off deforestation? — EUDR cut-off is 31 December 2020. Clarity on this is critical."
        },
        {
          "type": "rating_notes",
          "label": "Q17. Are you familiar with the EUDR and its implications for your farmers' cocoa supply chain? Have you received specific training? — EUDR is a significant regulatory risk for Brazilian cocoa exports to EU markets."
        },
        {
          "type": "section",
          "label": "SECTION 4 — AGROCHEMICAL ADVISORY & SAFETY"
        },
        {
          "type": "rating_notes",
          "label": "Q18. When you visit a farm, do you inspect the agrochemical storage area? What do you look for? — Should check: locked, ventilated, labelled containers, no prohibited products, no children's access."
        },
        {
          "type": "rating_notes",
          "label": "Q20. Are you aware of any prohibited or highly hazardous pesticides (WHO Class Ia/Ib or MAPA lista proibida)? Can you name examples? — Test knowledge. Should know: endosulfan banned; paraquat restricted; copper products require care."
        },
        {
          "type": "rating_notes",
          "label": "Q21. How do you advise farmers on PPE use? Do you check PPE condition and availability during visits? — Best practice: physical inspection of PPE; demonstration of correct use; replacement records."
        },
        {
          "type": "rating_notes",
          "label": "Q22. Does Kawa provide agrochemical alternatives, integrated pest management (IPM) training, or support for reducing chemical inputs? — Positive indicator of proactive risk management and sustainability transition support."
        },
        {
          "type": "rating_notes",
          "label": "Q23. How do you handle a situation where a farmer is using a product you know to be harmful or prohibited? — Listen for: immediate advice, documentation, escalation to Kawa agronomist, follow-up."
        },
        {
          "type": "section",
          "label": "SECTION 5 — LOAN ONBOARDING & FINANCIAL SAFEGUARDS"
        },
        {
          "type": "rating_notes",
          "label": "Q24. What is your role in the loan onboarding process for farmers? Do you participate in explaining loan terms? — Assess whether agents understand their responsibility for informed consent quality."
        },
        {
          "type": "rating_notes",
          "label": "Q25. How do you verify that a farmer has genuinely understood the loan terms before signing? — Best practice: farmer repeats terms back; independent verification; translated contract."
        },
        {
          "type": "rating_notes",
          "label": "Q26. Do you conduct a basic repayment capacity assessment before recommending a farmer for a loan? — Should consider: income, existing debt, household size, seasonal income volatility."
        },
        {
          "type": "rating_notes",
          "label": "Q27. Have you ever felt pressure from Kawa management or been given targets to sign up farmers quickly? — Sensitive but critical. Note tone and candour of response."
        },
        {
          "type": "rating_notes",
          "label": "Q28. How are community guarantee / solidarity group arrangements explained to farmers? Do you facilitate group formation? — Check whether agent explains cross-liability clearly and that group formation is voluntary."
        },
        {
          "type": "rating_notes",
          "label": "Q29. Do you follow up with farmers after loan disbursement to check they understand repayments and are managing well? — Post-disbursement follow-up is a good practice indicator for client protection."
        },
        {
          "type": "section",
          "label": "SECTION 6 — GRIEVANCE HANDLING & GENDER"
        },
        {
          "type": "rating_notes",
          "label": "Q30. Are farmers in your caseload aware that they can raise complaints about Kawa? How do they know? — Best practice: grievance mechanism communicated proactively at onboarding."
        },
        {
          "type": "rating_notes",
          "label": "Q31. Have any farmers raised complaints? About what? How were they resolved? — Listen for: range of issues, response time, farmer satisfaction, systemic issues."
        },
        {
          "type": "rating_notes",
          "label": "Q32. Have you ever had a complaint raised against you personally? How was it handled? — Tests whether internal accountability mechanisms exist and function."
        },
        {
          "type": "rating_notes",
          "label": "Q33. Do you actively seek out women farmers in your caseload for extension visits and training? — Women are often underserved by extension systems. Note structural barriers."
        },
        {
          "type": "rating_notes",
          "label": "Q34. Do you adapt your advisory approach for female-headed households? — Gender-responsive extension is a positive indicator."
        },
        {
          "type": "rating_notes",
          "label": "Q35. Are there indigenous or quilombola communities in your area? Have you received training on FPIC or indigenous rights? — Relevant for Pará especially. Absence of awareness in relevant areas is a gap."
        },
        {
          "type": "section",
          "label": "SECTION 7 — DATA, SYSTEMS & ORGANISATIONAL CAPACITY"
        },
        {
          "type": "rating_notes",
          "label": "Q36. What data do you record after each farm visit? Where is it stored — paper, app, central database? — Best practice: digital records with GPS, standardised fields, regular upload to central system."
        },
        {
          "type": "rating_notes",
          "label": "Q37. Do you record GPS coordinates and farm polygon boundaries for each farmer? Are these linked to their CAR registration? — Critical for EUDR traceability. Absence of geo-referenced farm data is a significant gap."
        },
        {
          "type": "rating_notes",
          "label": "Q38. How does Kawa use the data you collect? Do you receive feedback or follow-up actions based on your visit reports? — Assess whether data collection drives decisions or is merely compliance paperwork."
        },
        {
          "type": "rating_notes",
          "label": "Q39. Do you have adequate resources — motorbike/vehicle, smartphone, data connectivity — to do your job effectively? — Resource constraints directly affect quality of monitoring and support."
        },
        {
          "type": "rating_notes",
          "label": "Q40. What are the biggest challenges you face in carrying out your ESG-related responsibilities? — Open-ended. Look for: time pressure, farmer resistance, inadequate training, language barriers."
        }
      ]
    },
    {
      "id": "ta_ngo",
      "title": "TA & NGO Partner Staff",
      "questions": [
        {
          "type": "field",
          "label": "Staff name",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Organisation / role",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Date of interview",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Location / office",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Interviewer name",
          "input": "text"
        },
        {
          "type": "section",
          "label": "SECTION 1 — ORGANISATIONAL BACKGROUND & PROGRAMME SCOPE"
        },
        {
          "type": "rating_notes",
          "label": "Q1. What is your organisation's mandate in the Kawa/IDH cocoa programme? What specific TA activities do you deliver? — Understand scope: agroforestry, certification, gender, traceability, financial literacy, etc."
        },
        {
          "type": "rating_notes",
          "label": "Q2. How long has your organisation been working in this cocoa value chain and in this geographic area? — Assess institutional knowledge of local context, culture, and regulatory environment."
        },
        {
          "type": "rating_notes",
          "label": "Q3. How many technical staff are dedicated to this programme? What are their qualifications and languages spoken? — Note: Portuguese and local indigenous languages may be needed in Pará."
        },
        {
          "type": "rating_notes",
          "label": "Q4. Does your organisation have a formal ESG or safeguarding policy? Is it publicly available? When was it last reviewed? — Ask to see the policy. Absence or outdated policy (>3 years) is a governance gap."
        },
        {
          "type": "rating_notes",
          "label": "Q5. Are there any conflicts of interest between your organisation's activities and your role as an independent TA provider? — E.g. receiving fees from input suppliers, certification bodies, or buyers you recommend."
        },
        {
          "type": "section",
          "label": "SECTION 2 — CHILD LABOUR PREVENTION PROGRAMME"
        },
        {
          "type": "rating_notes",
          "label": "Q6. Does your TA programme include specific activities to prevent or remediate child labour? What are they? — Look for: awareness training, school enrolment support, income diversification, referral systems."
        },
        {
          "type": "rating_notes",
          "label": "Q7. How do your staff identify and respond to suspected child labour during field activities? Is there a documented protocol? How do you engage with Kawa and their field agents in these circumstances? — Best practice: written protocol, trained staff, documented referrals, follow-up records."
        },
        {
          "type": "rating_notes",
          "label": "Q8. Does your programme track child labour indicators at farmer level as part of M&E? — Quantitative tracking (school attendance rates, incidents reported) is a positive indicator."
        },
        {
          "type": "rating_notes",
          "label": "Q9. Do your staff receive training on these labour laws, child labour monitoring etc? — Test legal literacy. Training records should be requested. Check for awareness on Brazilian ECA and ILO conventions 138 & 182."
        },
        {
          "type": "rating_notes",
          "label": "Q10. Does your programme work with local Conselhos Tutelares, CRAS, or social protection services to address child vulnerability? — Integration with government social protection systems strengthens safeguarding outcomes."
        },
        {
          "type": "section",
          "label": "SECTION 3 — DEFORESTATION, EUDR & LAND RIGHTS"
        },
        {
          "type": "rating_notes",
          "label": "Q11. What TA does your organisation provide to help farmers understand and comply with the Forest Code (CAR, Reserva Legal, APP)? — Look for: CAR registration support, RL deficit remediation plans, legal advisory services."
        },
        {
          "type": "rating_notes",
          "label": "Q12. Are you familiar with the EUDR and its requirements for cocoa supply chain due diligence? Has your programme adapted/ are there still gaps? — EUDR requires geo-referenced farm polygons and post-2020 deforestation-free proof."
        },
        {
          "type": "rating_notes",
          "label": "Q13. Does your programme support farmers in generating geo-referenced farm boundary data (polygons)? What tools are used? — GPS polygon data is critical for EUDR compliance and deforestation monitoring."
        },
        {
          "type": "rating_notes",
          "label": "Q14. How does your programme address situations where a farmer's land shows historical deforestation? — Best practice: PRA enrolment support, reforestation planning, transition timeline with conditions."
        },
        {
          "type": "rating_notes",
          "label": "Q15. Does your programme work in areas with indigenous communities or quilombola territories? How is FPIC applied? — Critical for Pará region. Absence of FPIC protocols with traditional communities = red flag."
        },
        {
          "type": "rating_notes",
          "label": "Q16. What is your organisation's policy if a farmer is found to have deforested after 2020 (EUDR cut-off)? — Tests alignment with EUDR exclusion requirements and Kawa/IDH deforestation-free commitment."
        },
        {
          "type": "section",
          "label": "SECTION 4 — AGROCHEMICAL MANAGEMENT & IPM"
        },
        {
          "type": "rating_notes",
          "label": "Q17. Does your TA programme include training on IPM and reduction of hazardous agrochemical use? — Look for: IPM field schools, demonstration plots, alternative product trials, copper reduction."
        },
        {
          "type": "rating_notes",
          "label": "Q18. Do your field staff check for the use of prohibited or highly hazardous pesticides during farm visits? — Staff should know the MAPA prohibited list. Ask for examples of products flagged."
        },
        {
          "type": "rating_notes",
          "label": "Q19. Does your programme support safe chemical storage infrastructure or PPE access for smallholder farmers? — Practical support for safety infrastructure is a positive indicator."
        },
        {
          "type": "rating_notes",
          "label": "Q20. How do you handle situations where a farmer is using a product your programme has identified as high risk? — Listen for: advisory, documentation, referral to Kawa, exclusion criteria application."
        },
        {
          "type": "rating_notes",
          "label": "Q21. Does your programme work with farmers on soil health, agroforestry, and organic inputs as alternatives to synthetic inputs? — Climate resilience and chemical reduction go hand-in-hand. Positive indicator."
        },
        {
          "type": "section",
          "label": "SECTION 5 — GENDER & SOCIAL INCLUSION"
        },
        {
          "type": "rating_notes",
          "label": "Q22. Does your programme have explicit gender targets or a gender action plan? What % of beneficiaries are women? — Best practice: >40% women beneficiaries, gender-disaggregated data, women in leadership."
        },
        {
          "type": "rating_notes",
          "label": "Q23. How does your programme reach women farmers who face mobility restrictions, lower literacy, or limited mobile access? — Inclusive design should address specific barriers. Note practical adaptations."
        },
        {
          "type": "rating_notes",
          "label": "Q24. Does your programme address women's land rights and access to credit? Activities for female-headed households? — Women's tenure security and financial inclusion are core IFC PS 1 indicators."
        },
        {
          "type": "rating_notes",
          "label": "Q25. Are training materials available in local languages and adapted for low-literacy participants? — In Pará especially, indigenous languages may be needed. Note availability."
        },
        {
          "type": "rating_notes",
          "label": "Q26. Does your organisation have a PSEAH (protection from sexual exploitation, abuse and harassment) policy? — A PSEAH policy is a minimum standard for any NGO working with vulnerable populations."
        },
        {
          "type": "rating_notes",
          "label": "Q27. How are the needs of indigenous and quilombola communities specifically addressed in your programme design? — Look for: separate workplans, culturally adapted materials, indigenous staff, FPIC processes."
        },
        {
          "type": "section",
          "label": "SECTION 6 — M&E, DATA QUALITY & EVIDENCE"
        },
        {
          "type": "rating_notes",
          "label": "Q28. What is your programme's M&E framework? What ESG indicators do you track at farmer level? — Should include: child labour incidents, CAR compliance rate, PPE use, women beneficiaries, income."
        },
        {
          "type": "rating_notes",
          "label": "Q29. How is data collected — paper forms, mobile apps, GPS? How is data quality controlled and verified? — Digital data collection with GPS is the standard. Note any data quality audits."
        },
        {
          "type": "rating_notes",
          "label": "Q30. How frequently do you report programme data to Kawa? In what format? — Regular, standardised reporting (quarterly minimum) with ESG indicators is expected."
        },
        {
          "type": "rating_notes",
          "label": "Q31. Has your programme been subject to an independent external evaluation? What were the key findings? — External evaluations test rigour and accountability. Ask for the evaluation report."
        },
        {
          "type": "rating_notes",
          "label": "Q32. Do you have a system for tracking and responding to grievances raised by beneficiaries? How many in last 12 months? — A functioning grievance log with resolution rates is a key accountability indicator."
        },
        {
          "type": "rating_notes",
          "label": "Q33. How do you ensure programme data is not influenced by pressure from Kawa or IDH to show positive results? — Tests independence. Listen for: firewall between M&E and programme delivery, independent verification."
        },
        {
          "type": "section",
          "label": "SECTION 7 — COORDINATION WITH KAWA & STRATEGIC ALIGNMENT"
        },
        {
          "type": "rating_notes",
          "label": "Q34. How does your organisation coordinate with Kawa's field extension agents on farm visits and technical advice? — Good coordination avoids duplication and ensures consistent farmer messaging."
        },
        {
          "type": "rating_notes",
          "label": "Q35. Are there areas where your technical advice to farmers has conflicted with Kawa's commercial or operational interests? — Tests independence and whether commercial pressure compromises TA quality."
        },
        {
          "type": "rating_notes",
          "label": "Q36. Does your programme have any role in recommending or endorsing specific input suppliers, buyers, or financial products? — Conflict of interest if NGO receives commission or benefit from commercial recommendations."
        },
        {
          "type": "rating_notes",
          "label": "Q37. How do you share ESG risk information — child labour, deforestation, forced labour — with Kawa? Is there a formal protocol? — Information sharing protocol is essential. Ad hoc sharing creates accountability gaps."
        },
        {
          "type": "rating_notes",
          "label": "Q38. What, in your assessment, are the top three ESG risks in the Kawa cocoa supply chain in this region? — Open-ended. Captures expert field perspective. Note risks not already covered."
        },
        {
          "type": "rating_notes",
          "label": "Q39. Are there any practices or policies of Kawa you believe are inconsistent with good ESG standards? Have you raised these formally? — Tests whether NGO is a genuine watchdog or merely a service provider."
        },
        {
          "type": "rating_notes",
          "label": "Q40. What additional support — from Kawa, IDH, or other funders — would most improve ESG outcomes in this supply chain? — Captures unmet needs and systemic gaps from a practitioner perspective."
        }
      ]
    },
    {
      "id": "risk",
      "title": "Risk Scoring Summary",
      "questions": [
        {
          "type": "field",
          "label": "Assessment date",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Assessment lead",
          "input": "text"
        },
        {
          "type": "field",
          "label": "Kawa Fund contact",
          "input": "text"
        },
        {
          "type": "field",
          "label": "IDH Farmfit reviewer",
          "input": "text"
        },
        {
          "type": "section",
          "label": "FARMER INTERVIEW THEMES"
        },
        {
          "type": "risk",
          "label": "1. Land tenure & title security"
        },
        {
          "type": "risk",
          "label": "2. CAR / Forest Code compliance"
        },
        {
          "type": "risk",
          "label": "3. Deforestation (historical & current)"
        },
        {
          "type": "risk",
          "label": "4. Proximity to protected / indigenous areas"
        },
        {
          "type": "risk",
          "label": "5. Child labour risk"
        },
        {
          "type": "risk",
          "label": "6. Forced / bonded labour risk"
        },
        {
          "type": "risk",
          "label": "7. Worker conditions & safety"
        },
        {
          "type": "risk",
          "label": "8. Agrochemical use & storage"
        },
        {
          "type": "risk",
          "label": "9. Hazardous / prohibited substances"
        },
        {
          "type": "risk",
          "label": "10. PPE & occupational health"
        },
        {
          "type": "risk",
          "label": "11. Loan understanding & informed consent"
        },
        {
          "type": "risk",
          "label": "12. Over-indebtedness risk"
        },
        {
          "type": "risk",
          "label": "13. Group guarantee understanding"
        },
        {
          "type": "risk",
          "label": "14. Gender & women's inclusion"
        },
        {
          "type": "risk",
          "label": "15. Climate risk & resilience"
        },
        {
          "type": "risk",
          "label": "16. Biodiversity & natural resource use"
        },
        {
          "type": "section",
          "label": "FIELD EXTENSION AGENT THEMES"
        },
        {
          "type": "risk",
          "label": "17. Quality & frequency of farm visits"
        },
        {
          "type": "risk",
          "label": "18. Child labour awareness & response protocol"
        },
        {
          "type": "risk",
          "label": "19. Deforestation monitoring practice"
        },
        {
          "type": "risk",
          "label": "20. CAR / Forest Code farmer support"
        },
        {
          "type": "risk",
          "label": "21. Agrochemical advisory capacity"
        },
        {
          "type": "risk",
          "label": "22. Loan onboarding & informed consent process"
        },
        {
          "type": "risk",
          "label": "23. Grievance mechanism knowledge & use"
        },
        {
          "type": "risk",
          "label": "24. Data recording & traceability systems"
        },
        {
          "type": "risk",
          "label": "25. Gender & inclusion in field work"
        },
        {
          "type": "section",
          "label": "TA / NGO PARTNER STAFF THEMES"
        },
        {
          "type": "risk",
          "label": "26. Programme design alignment with EUDR"
        },
        {
          "type": "risk",
          "label": "27. Child labour prevention programme"
        },
        {
          "type": "risk",
          "label": "28. Agroforestry / climate resilience TA"
        },
        {
          "type": "risk",
          "label": "29. Gender mainstreaming in TA activities"
        },
        {
          "type": "risk",
          "label": "30. FPIC / indigenous rights protocols"
        },
        {
          "type": "risk",
          "label": "31. Coordination quality with Kawa"
        },
        {
          "type": "risk",
          "label": "32. Organisational ESG capacity & independence"
        },
        {
          "type": "section",
          "label": "COMBINED / CROSS-CUTTING THEMES"
        },
        {
          "type": "risk",
          "label": "33. Overall child labour risk (all sources)"
        },
        {
          "type": "risk",
          "label": "34. Overall deforestation / EUDR risk (all sources)"
        },
        {
          "type": "risk",
          "label": "35. Overall land tenure risk (all sources)"
        },
        {
          "type": "risk",
          "label": "36. Overall agrochemical risk (all sources)"
        },
        {
          "type": "risk",
          "label": "37. Overall financial inclusion risk (all sources)"
        },
        {
          "type": "risk",
          "label": "38. Overall gender & inclusion risk (all sources)"
        },
        {
          "type": "risk",
          "label": "39. Overall ESG risk rating"
        },
        {
          "type": "section",
          "label": "High risk count (H):"
        },
        {
          "type": "section",
          "label": "Medium risk count (M):"
        },
        {
          "type": "section",
          "label": "Low risk count (L):"
        },
        {
          "type": "section",
          "label": "EXCLUSION TRIGGERS — Escalate immediately: (1) Post-2020 deforestation on farm polygon | (2) Farm overlaps Indigenous Land / quilombola territory / IBAMA embargo | (3) Child labour in worst forms | (4) Forced / bonded labour | (5) WHO Class Ia/Ib or MAPA-prohibited pesticides | (6) Farm inside Federal Conservation Unit"
        }
      ]
    }
  ]
};
